import google.generativeai as genai
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import logging
from typing import Optional, List
import os
from dotenv import load_dotenv

# Load environment variables and setup logging
load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI
app = FastAPI(title="AI Note Taker API")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure Gemini API
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel('gemini-2.0-flash')

# Pydantic models
class NoteRequest(BaseModel):
    text: str

class NoteResponse(BaseModel):
    success: bool
    note: Optional[str] = None
    error: Optional[str] = None

def generate_prompt(text: str) -> str:
    return f"""Create an enhanced note from the following text that is clear and simple to understand.

    Text to Process:
    {text}

    Please structure your response using this format:

    # Quick Summary
    Write 2-3 sentences that capture the main idea using simple, everyday words.

    # Key Points
    - Break down the most important ideas
    - Use bullet points
    - Keep each point to one line

    # Simple Explanation
    Explain the topic as if you're telling it to a friend.

    # Remember This! ⭐
    The single most important takeaway in one simple sentence.
    """

@app.post("/generate-note", response_model=NoteResponse)
async def generate_note(request: NoteRequest):
    try:
        # Print incoming request with clear formatting
        print("\n" + "="*50)
        print("NEW NOTE REQUEST")
        print("="*50)
        print("SELECTED TEXT:")
        print(request.text)
        print("-"*50)

        # Generate prompt and get response from Gemini
        prompt = generate_prompt(request.text)
        response = model.generate_content(prompt)
        
        # Print the generated response with clear formatting
        print("GENERATED NOTE:")
        print(response.text)
        print("="*50 + "\n")

        return NoteResponse(
            success=True,
            note=response.text
        )
    except Exception as e:
        print("\n" + "!"*50)
        print(f"ERROR: {str(e)}")
        print("!"*50 + "\n")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
