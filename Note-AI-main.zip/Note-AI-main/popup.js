document.addEventListener('DOMContentLoaded', () => {
  const noteContent = document.getElementById('noteContent');

  // Load the last generated note
  chrome.storage.local.get('lastNote', (data) => {
    if (data.lastNote) {
      noteContent.value = data.lastNote.generatedNote;
    }
  });

  // Add generate note button handler
  document.getElementById('generateNote').addEventListener('click', async () => {
    // Get current active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Get selected text
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => window.getSelection().toString(),
    }, async (results) => {
      if (!results[0].result) {
        noteContent.value = 'Please select some text first!';
        return;
      }

      try {
        const response = await fetch("https://note-ai-p5a8.onrender.com/generate-note", {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: results[0].result })
        });

        const data = await response.json();
        if (data.success) {
          noteContent.value = data.note;
        } else {
          noteContent.value = 'Error: ' + data.error;
        }
      } catch (error) {
        noteContent.value = 'Error generating note: ' + error.message;
      }
    });
  });

  // Clear note handler
  document.getElementById('clearNote').addEventListener('click', () => {
    noteContent.value = '';
    chrome.storage.local.remove('lastNote');
  });
}); 
