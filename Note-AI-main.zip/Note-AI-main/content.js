console.log('Content script loaded');

// Create floating button
const floatingButton = document.createElement('button');
floatingButton.className = 'floating-note-button';
floatingButton.innerHTML = '+';
floatingButton.title = 'Generate Note';
floatingButton.onclick = () => {
  const selectedText = window.getSelection().toString();
  if (selectedText.trim()) {
    chrome.runtime.sendMessage({ action: 'generateNote', text: selectedText });
  } else {
    showErrorPopup('Please select some text first!');
  }
};
document.body.appendChild(floatingButton);

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received in content script:', message);
  if (message.action === 'showNote') {
    showNotePopup(message.note);
  } else if (message.action === 'showError') {
    showErrorPopup(message.message);
  }
});

function showNotePopup(noteContent) {
  console.log('Showing note popup');
  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = 'ai-note-overlay';
  
  // Create popup
  const popup = document.createElement('div');
  popup.className = 'ai-note-popup';
  
  // Create close button
  const closeButton = document.createElement('button');
  closeButton.className = 'close-button';
  closeButton.innerHTML = '×';
  closeButton.onclick = () => {
    document.body.removeChild(overlay);
  };
  
  // Create textarea
  const textarea = document.createElement('textarea');
  textarea.value = noteContent;
  textarea.readOnly = true;
  
  // Assemble popup
  popup.appendChild(closeButton);
  popup.appendChild(textarea);
  overlay.appendChild(popup);
  
  // Add to page
  document.body.appendChild(overlay);
}

function showErrorPopup(message) {
  console.log('Showing error popup');
  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = 'ai-note-overlay';
  
  // Create popup
  const popup = document.createElement('div');
  popup.className = 'ai-note-popup error';
  
  // Create close button
  const closeButton = document.createElement('button');
  closeButton.className = 'close-button';
  closeButton.innerHTML = '×';
  closeButton.onclick = () => {
    document.body.removeChild(overlay);
  };
  
  // Create error message
  const errorMessage = document.createElement('p');
  errorMessage.className = 'error-message';
  errorMessage.textContent = message;
  
  // Assemble popup
  popup.appendChild(closeButton);
  popup.appendChild(errorMessage);
  overlay.appendChild(popup);
  
  // Add to page
  document.body.appendChild(overlay);
}