// Initialize context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "generateNote",
    title: "Generate Note",
    contexts: ["selection"]
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "generateNote") {
    processSelectedText(info.selectionText, tab.id);
  }
});

// Handle extension icon clicks
chrome.action.onClicked.addListener(async (tab) => {
  // Get selected text from the active tab
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: getSelectedText,
  }, async (results) => {
    if (results && results[0] && results[0].result) {
      await processSelectedText(results[0].result, tab.id);
    }
  });
});

// Function to get selected text
function getSelectedText() {
  return window.getSelection().toString();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'generateNote') {
    processSelectedText(message.text, sender.tab.id);
  }
});

async function processSelectedText(text, tabId) {
  try {
    if (!text.trim()) {
      chrome.tabs.sendMessage(tabId, {
        action: 'showError',
        message: 'Please select some text first!'
      });
      return;
    }

    console.log('Selected Text:', text);
    console.log('-------------------');

    const response = await fetch("https://note-ai-p5a8.onrender.com/generate-note", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text: text })
    });

    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error);
    }

    console.log('Generated Note:');
    console.log(data.note);
    console.log('-------------------');

    chrome.tabs.sendMessage(tabId, {
      action: 'showNote',
      note: data.note
    });
    console.log('Message sent to content script');
  } catch (error) {
    console.error('Error:', error);
    chrome.tabs.sendMessage(tabId, {
      action: 'showError',
      message: 'Error generating note: ' + error.message
    });
  }
}
